package bg.softuni.enums;

/**
 * Created by Niki on 5.8.2016 г..
 */
public enum StatusType {
    NORMAL,
    CRITICAL;
}
