package bg.softuni.enums;

public enum FragmentType {
    Nuclear,
    Cooling
}
