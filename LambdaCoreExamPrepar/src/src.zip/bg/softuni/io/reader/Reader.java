package bg.softuni.io.reader;

import java.io.IOException;

public interface Reader {

    String readLine() throws IOException;

}
