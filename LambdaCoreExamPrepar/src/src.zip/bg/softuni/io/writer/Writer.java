package bg.softuni.io.writer;

public interface Writer {

    void writeLine(String line);

}
