package tests;


import org.junit.Test;

/**
 * Created by Niki on 6.8.2016 г..
 */
public class LStackTest {

    @Test
    public void size(){
        
    }
}